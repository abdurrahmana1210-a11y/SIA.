# Meri Awaz – Offline Urdu Voice Assistant (Android)

## APK banane ka tareeqa
1. Android Studio (Koala ya naya) install karein.
2. `VoiceAssistant` folder ko **File → Open** se kholein, Gradle sync hone dein (pehli dafa internet chahiye).
3. **Build → Build APK(s)**. APK yahan milega: `app/build/outputs/apk/debug/app-debug.apk`
4. APK phone mein copy karke install karein.

## Offline chalane ke liye phone mein 2 cheezein (ek dafa)
- **Urdu sunne ke liye:** Settings → Google → Settings for Google apps → Search, Assistant & Voice → Voice → Offline speech recognition → **Urdu** download.
  (Ya Settings → Apps → Speech Services by Google se.)
- **Urdu bolne ke liye:** Settings → System → Languages → Text-to-speech output → Google ke Engine → Install voice data → **Urdu**.
  Na ho to app Hindi awaz use karti hai.

## Kya hukam samajhta hai
| Hukam | Misaal |
|---|---|
| Waqt | "وقت کیا ہوا ہے" / "time batao" |
| Tareekh | "آج کی تاریخ" / "date" |
| App kholna | "واٹس ایپ کھولو" / "open youtube" |
| Call | "علی کو کال کرو" / "call ali" |
| Alarm | "صبح سات بجے الارم" / "alarm 7:30" |
| Timer | "پانچ منٹ کا ٹائمر" |

## Hudood
- Awaz pehchanne ki durusti phone ke Google offline Urdu model par hai; Urdu offline model English se kam accurate hota hai.
- Contacts agar English mein save hain to Urdu bol kar naam match nahi hoga; number bol kar ya English naam bol kar call karein.
- Naye hukam `CommandHandler.kt` mein `handle()` ke andar add karein.
