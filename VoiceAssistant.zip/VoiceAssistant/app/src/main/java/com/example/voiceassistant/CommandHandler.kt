package com.example.voiceassistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.AlarmClock
import android.provider.ContactsContract
import java.util.Calendar

/**
 * Bole gaye alfaaz (Urdu ya Roman Urdu) ko samajh kar action karta hai.
 * Sab kuch offline hai: koi internet nahi chahiye.
 */
class CommandHandler(private val activity: Activity) {

    private val urduMonths = listOf(
        "جنوری", "فروری", "مارچ", "اپریل", "مئی", "جون",
        "جولائی", "اگست", "ستمبر", "اکتوبر", "نومبر", "دسمبر"
    )
    private val urduDays = listOf(
        "اتوار", "پیر", "منگل", "بدھ", "جمعرات", "جمعہ", "ہفتہ"
    )

    // Urdu / Roman Urdu naam -> app ka asli naam (label ya package ka hissa)
    private val appAliases = mapOf(
        "واٹس ایپ" to "whatsapp", "وٹس ایپ" to "whatsapp", "whatsapp" to "whatsapp",
        "یوٹیوب" to "youtube", "youtube" to "youtube",
        "کیمرہ" to "camera", "کیمرا" to "camera", "camera" to "camera",
        "گیلری" to "gallery", "تصاویر" to "photos", "gallery" to "gallery",
        "کروم" to "chrome", "chrome" to "chrome",
        "سیٹنگ" to "settings", "سیٹنگز" to "settings", "settings" to "settings",
        "کیلکولیٹر" to "calculator", "calculator" to "calculator",
        "فیس بک" to "facebook", "facebook" to "facebook",
        "انسٹاگرام" to "instagram", "instagram" to "instagram",
        "ٹک ٹاک" to "tiktok", "tiktok" to "tiktok",
        "گھڑی" to "clock", "clock" to "clock",
        "میسج" to "messages", "پیغامات" to "messages", "messages" to "messages"
    )

    private val numberWords = mapOf(
        "ایک" to 1, "ek" to 1, "دو" to 2, "do" to 2, "تین" to 3, "teen" to 3,
        "چار" to 4, "char" to 4, "پانچ" to 5, "panch" to 5, "paanch" to 5,
        "چھ" to 6, "chay" to 6, "che" to 6, "سات" to 7, "saat" to 7,
        "آٹھ" to 8, "aath" to 8, "نو" to 9, "nau" to 9, "دس" to 10, "das" to 10,
        "گیارہ" to 11, "بارہ" to 12, "پندرہ" to 15, "pandrah" to 15,
        "بیس" to 20, "bees" to 20, "تیس" to 30, "tees" to 30,
        "پینتالیس" to 45, "ساٹھ" to 60
    )

    /** Hukam chalata hai aur jawab ka text wapas deta hai (wahi bola bhi jata hai). */
    fun handle(raw: String): String {
        val text = normalize(raw)
        if (text.isBlank()) return "مجھے سمجھ نہیں آیا، دوبارہ بولیں"

        return when {
            hasAny(text, "الارم", "alarm") -> setAlarm(text)
            hasAny(text, "ٹائمر", "timer") -> setTimer(text)
            hasAny(text, "کال", "call", "phone", "فون") -> makeCall(text)
            hasAny(text, "کھولو", "کھول", "kholo", "open", "چلاؤ") -> openApp(text)
            hasAny(text, "تاریخ", "tareekh", "date", "آج کیا دن", "دن") -> tellDate()
            hasAny(text, "وقت", "waqt", "time", "بجے ہیں", "کتنے بجے") -> tellTime()
            else -> "معذرت، میں یہ کام ابھی نہیں کر سکتا"
        }
    }

    // ---------------- Waqt / Tareekh ----------------

    private fun tellTime(): String {
        val c = Calendar.getInstance()
        var h = c.get(Calendar.HOUR)
        if (h == 0) h = 12
        val m = c.get(Calendar.MINUTE)
        val period = when (c.get(Calendar.HOUR_OF_DAY)) {
            in 4..11 -> "صبح"
            in 12..15 -> "دوپہر"
            in 16..18 -> "شام"
            else -> "رات"
        }
        return if (m == 0) "$period کے $h بجے ہیں" else "$period کے $h بج کر $m منٹ ہوئے ہیں"
    }

    private fun tellDate(): String {
        val c = Calendar.getInstance()
        val day = urduDays[c.get(Calendar.DAY_OF_WEEK) - 1]
        val month = urduMonths[c.get(Calendar.MONTH)]
        return "آج $day ہے، ${c.get(Calendar.DAY_OF_MONTH)} $month ${c.get(Calendar.YEAR)}"
    }

    // ---------------- Alarm / Timer ----------------

    private fun setAlarm(text: String): String {
        val nums = extractNumbers(text)
        if (nums.isEmpty()) return "الارم کس وقت کا لگانا ہے؟ مثلاً: الارم سات بجے"
        var hour = nums[0]
        val minute = if (nums.size > 1) nums[1] else 0
        val isPm = hasAny(text, "شام", "sham", "shaam", "رات", "raat", "دوپہر", "pm")
        val isAm = hasAny(text, "صبح", "subah", "am")
        if (isPm && hour < 12) hour += 12
        if (isAm && hour == 12) hour = 0
        if (hour !in 0..23 || minute !in 0..59) return "وقت درست نہیں لگتا، دوبارہ بولیں"

        val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
            putExtra(AlarmClock.EXTRA_HOUR, hour)
            putExtra(AlarmClock.EXTRA_MINUTES, minute)
            putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        }
        return startSafely(intent, "الارم $hour:${"%02d".format(minute)} پر لگا دیا")
    }

    private fun setTimer(text: String): String {
        val nums = extractNumbers(text)
        if (nums.isEmpty()) return "ٹائمر کتنی دیر کا لگانا ہے؟ مثلاً: پانچ منٹ کا ٹائمر"
        val n = nums[0]
        val seconds = when {
            hasAny(text, "سیکنڈ", "second", "sec") -> n
            hasAny(text, "گھنٹہ", "گھنٹے", "ghanta", "ghante", "hour") -> n * 3600
            else -> n * 60
        }
        val intent = Intent(AlarmClock.ACTION_SET_TIMER).apply {
            putExtra(AlarmClock.EXTRA_LENGTH, seconds)
            putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        }
        return startSafely(intent, "ٹائمر لگا دیا")
    }

    // ---------------- App kholna ----------------

    private fun openApp(text: String): String {
        var target = text
        listOf("کھولو", "کھول دو", "کھول", "kholo", "open", "چلاؤ", "ایپ", "app").forEach {
            target = target.replace(it, " ")
        }
        target = target.trim()
        if (target.isEmpty()) return "کون سی ایپ کھولنی ہے؟"

        val wanted = appAliases.entries.firstOrNull { target.contains(it.key) }?.value ?: target

        val pm = activity.packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launcher, 0)
        val match = apps.firstOrNull {
            it.loadLabel(pm).toString().lowercase().contains(wanted)
        } ?: apps.firstOrNull { it.activityInfo.packageName.lowercase().contains(wanted) }
        ?: return "مجھے $target نام کی ایپ نہیں ملی"

        val intent = pm.getLaunchIntentForPackage(match.activityInfo.packageName)
            ?: return "یہ ایپ نہیں کھل سکی"
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        activity.startActivity(intent)
        return "${match.loadLabel(pm)} کھول رہا ہوں"
    }

    // ---------------- Call ----------------

    private fun makeCall(text: String): String {
        var name = text
        listOf("کال کرو", "کال", "call", "phone", "فون کرو", "فون", "کو", "ko", "کر دو", "کرو", "karo")
            .forEach { name = name.replace(it, " ") }
        name = name.trim().replace(Regex("\\s+"), " ")
        if (name.isEmpty()) return "کس کو کال کرنی ہے؟"

        if (!has(Manifest.permission.CALL_PHONE)) return "کال کی اجازت نہیں ملی"

        val digits = name.replace(" ", "")
        val number = if (digits.matches(Regex("[+0-9]{6,15}"))) digits else findContactNumber(name)
            ?: return "رابطوں میں $name نہیں ملا"

        activity.startActivity(
            Intent(Intent.ACTION_CALL, Uri.parse("tel:$number")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
        return "$name کو کال کر رہا ہوں"
    }

    private fun findContactNumber(name: String): String? {
        if (!has(Manifest.permission.READ_CONTACTS)) return null
        val cursor = activity.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
            arrayOf("%$name%"),
            null
        ) ?: return null
        cursor.use { if (it.moveToFirst()) return it.getString(0) }
        return null
    }

    // ---------------- Madadgar ----------------

    private fun has(permission: String) =
        activity.checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED

    private fun startSafely(intent: Intent, okMessage: String): String =
        try {
            activity.startActivity(intent)
            okMessage
        } catch (e: Exception) {
            "یہ کام اس فون پر نہیں ہو سکا"
        }

    private fun hasAny(text: String, vararg words: String) = words.any { text.contains(it) }

    private fun normalize(s: String): String {
        val sb = StringBuilder()
        for (ch in s.lowercase().trim()) {
            sb.append(
                when (ch) {
                    in '۰'..'۹' -> ('0' + (ch - '۰'))   // Urdu digits
                    in '٠'..'٩' -> ('0' + (ch - '٠'))   // Arabic digits
                    else -> ch
                }
            )
        }
        return sb.toString()
    }

    /** Text se numbers nikalta hai: "7:30", "سات بجے", "5 منٹ" sab chalte hain. */
    private fun extractNumbers(text: String): List<Int> {
        val out = mutableListOf<Int>()
        for (token in text.split(Regex("[\\s:.,]+"))) {
            token.toIntOrNull()?.let { out.add(it); continue }
            numberWords[token]?.let { out.add(it) }
        }
        return out
    }
}
