package com.example.voiceassistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.util.Locale

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {

    private lateinit var status: TextView
    private lateinit var log: TextView
    private lateinit var micBtn: Button
    private lateinit var commands: CommandHandler
    private lateinit var tts: TextToSpeech
    private var ttsReady = false
    private var recognizer: SpeechRecognizer? = null

    private val urdu = Locale("ur", "PK")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        status = findViewById(R.id.status)
        log = findViewById(R.id.log)
        micBtn = findViewById(R.id.micBtn)
        commands = CommandHandler(this)
        tts = TextToSpeech(this, this)

        micBtn.setOnClickListener { startListening() }
        requestPermissions(
            arrayOf(
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.CALL_PHONE,
                Manifest.permission.READ_CONTACTS
            ), 1
        )
    }

    // ---------- Bolna (TTS, offline) ----------

    override fun onInit(code: Int) {
        if (code != TextToSpeech.SUCCESS) return
        var r = tts.setLanguage(urdu)
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            // Urdu awaz install nahi: Hindi se kaam chalao (Urdu text kaafi had tak parh leti hai)
            r = tts.setLanguage(Locale("hi", "IN"))
        }
        ttsReady = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED
        if (!ttsReady) addLog("⚠️ اردو آواز انسٹال نہیں۔ فون کی Text-to-speech سیٹنگ میں اردو آواز ڈاؤنلوڈ کریں۔")
    }

    private fun say(text: String) {
        addLog("🤖 $text")
        if (ttsReady) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "reply")
    }

    // ---------- Sunna (offline speech recognition) ----------

    private fun startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            status.text = "مائیک کی اجازت دیں"
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
            return
        }
        recognizer?.destroy()
        recognizer = createRecognizer() ?: run {
            status.text = "اس فون پر آواز پہچاننے کی سہولت نہیں"
            return
        }
        recognizer?.setRecognitionListener(listener)

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ur-PK")
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        tts.stop()
        recognizer?.startListening(intent)
    }

    private fun createRecognizer(): SpeechRecognizer? {
        // Android 13+: sirf device par chalne wala recognizer (bilkul offline)
        if (Build.VERSION.SDK_INT >= 33 && SpeechRecognizer.isOnDeviceRecognitionAvailable(this)) {
            return SpeechRecognizer.createOnDeviceSpeechRecognizer(this)
        }
        if (SpeechRecognizer.isRecognitionAvailable(this)) {
            return SpeechRecognizer.createSpeechRecognizer(this)
        }
        return null
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) { status.text = "سن رہا ہوں…" }
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() { status.text = "سمجھ رہا ہوں…" }
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onError(error: Int) {
            status.text = "مائیک دبائیں اور بولیں"
            val msg = when (error) {
                SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT ->
                    "کچھ سنائی نہیں دیا، دوبارہ بولیں"
                12, 13 -> // LANGUAGE_NOT_SUPPORTED / LANGUAGE_UNAVAILABLE
                    "اردو آف لائن پیک انسٹال نہیں۔ Google ایپ ← سیٹنگز ← آواز ← آف لائن اسپیچ ریکگنیشن ← اردو"
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "مائیک کی اجازت دیں"
                else -> "آواز پہچاننے میں مسئلہ ($error)"
            }
            addLog("⚠️ $msg")
        }

        override fun onResults(results: Bundle?) {
            status.text = "مائیک دبائیں اور بولیں"
            val heard = results
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull().orEmpty()
            addLog("🗣️ $heard")
            say(commands.handle(heard))
        }
    }

    private fun addLog(line: String) {
        log.append(line + "\n\n")
    }

    override fun onDestroy() {
        recognizer?.destroy()
        tts.shutdown()
        super.onDestroy()
    }
}
